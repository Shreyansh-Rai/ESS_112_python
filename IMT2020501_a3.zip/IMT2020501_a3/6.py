n= int(input())

if n%2==0 :
    for i in range(1,n,2): #loop from 1 to n and incrementing by 2 printing 
        print(3*i,end= " ")
    print()    
else :
    for i in range(0,n,2): #going from 0 to n-1 and incrementing by 2 each iteration to print 2*i
        print(2*i, end=" ")
    print()
