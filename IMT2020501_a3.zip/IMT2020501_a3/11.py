n=int(input())
s=[]
for i in range(n) : #taking input and storing eligible or not eligible into the list .
    t=int(input())
    if t>=18:
        s.append('Eligible')
    else : 
        s.append('Not Eligible')
print(s) #display the list
