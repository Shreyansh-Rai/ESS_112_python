s1=input()
s2=input()
s1=s1.split(',')
s2=s2.split(',')

if len(s1) != len(s2) : #if the lengths are unequal 
    print('Lengths of the array are not equal')

else :
    for i in range(len(s1)) : #iterating through the array and adding elements in the corresponding places
        s1[i]=int(s1[i])+int(s2[i])
    print(s1)
