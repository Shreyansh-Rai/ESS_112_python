n=int(input())
o=3
c=1
while c<=n :
    print(o**2,end=" ") #printing the squares of the first 5 numbers divisible by 3
    c+=1
    o+=3
print()
