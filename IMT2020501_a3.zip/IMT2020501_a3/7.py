n=int(input())
k=1
c=1
while (k<=n):
    print(c,end=" ")
    c+=2 #the odd number to be printed
    k+=1 #keeping track of how many to print
print()

