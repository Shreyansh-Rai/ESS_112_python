l=int(input())
a=[]
i=0
for i in range(0,l) :
    t=int(input()) #inputting numbers into the list
    a.append(t)
x=int(input())
y=int(input())

for i in a :
    if i%x == 0 and i%y==0 : #if number is divisible by both the input numbers then print
        print(i,end=" ")

