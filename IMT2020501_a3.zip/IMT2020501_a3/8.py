d1=input()
d2=input()
d1=d1.split(',')
d2=d2.split(',')
d1=list(map(int,d1))
d2=list(map(int,d2)) #converting the list from string into int
if d1[2]>d2[2]:
    print("The date that occurs later is",d1)
elif d1[2]<d2[2] :
    print("The date that occurs later is",d2)
elif d1[2]==d2[2] :
    if d1[1]>d2[1] :
        print("The date that occurs later is",d1)
    elif d1[1]<d2[1]:
        print("The date that occurs later is",d2)
    else:
        if(d1[0]>d2[0]) :
            print("The date that occurs later is",d1)
        elif d1[0]<d2[0] :
            print("The date that occurs later is",d2)
        else :
            print("They are the same date")
