n=int(input())

for i in range(1,n+1): #outer loop controlling the number of rows 
    for j in range(1,i+1): #inner loop printing j that goes up to i for each iteration of the outer loop
        print(j,end=" ")
    print() #to print the next line on a new line

