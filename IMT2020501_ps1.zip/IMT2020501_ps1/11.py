
li=input().split(',') #getting the list

l=[]
for i in range(len(li)) :
    num=int(li[i])
    if num%2==0 :
        l.append(num*2) #adding the even numbers into a list 
print(l)
print(sum(l))