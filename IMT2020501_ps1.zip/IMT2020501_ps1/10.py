s=input()
s=tuple(s.split(' '))
for i in range(len(s)) :
    s=list(s) #tuple can't be directly modified and so it has been converted into a string first
    s[i]='not '+s[i]
    s=tuple(s)
print(s)
    