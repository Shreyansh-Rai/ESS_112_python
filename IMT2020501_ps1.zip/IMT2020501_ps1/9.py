dp={'Tomato':25.49,'Potato':30.25,'Carrot':70,'Cucumber':30.29,'Apple':100.10,'Orange':40,'Banana':65}

print("Enter the number of inputs")
inp=int(input())
pr=0
for i in range(inp):
    veg=input()
    qty=float(input())
    pr+=dp[veg]*qty
print("%.2f"%(pr))
