r=int(input())
c=int(input())
l=[[0 for j in range(c)] for i in range(r)] #init a 2D list with r rows and c columns
lt=[[0 for j in range(r)] for i in range(c)] #init a 2D list transpose
print(l)
for i in range(r) :
    for j in range(c) :
        l[i][j]=int(input()) #initialising the array 
        lt[j][i]=l[i][j] #transpose init.
print(lt)