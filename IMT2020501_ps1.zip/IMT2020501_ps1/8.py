x=int(input())
y=int(input())
z=int(input())
k=0
for i in range(x,y+1) :
    if i%z==0 :
        k+=1
print(k)