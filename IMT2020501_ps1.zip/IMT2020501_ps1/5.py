n=int(input())
#using for loop
f=1
for i in range(1,n+1) :
    f*=i
print(f)
#using while loop
i=1
f=1
while i<=5 :
    f*=i
    i+=1
print(f)