
l1=[]
l2=[]
l1=input().split(',')
for i in range(len(l1)):
    l1[i]=int(l1[i])
l2.append(l1[0]**2)
l2=l2+l1[1:]
print(l1)
print(l2)