playlist ={
            "Kana-Boon":   [
                            ("Silhouette", "TIME", 2015),
                            ("Fighter", "Fighter", 2017),
                            ("Klaxon", "TIME", 2015)
                            ],
            "Man with a mission":   [
                            ("Dead end in Tokyo", "Dead end in Tokyo", 2017),
                            ("Raise your flag", "Dead end in Tokyo", 2017),
                            ("Brave it out", "Dead end in Tokyo", 2017)
                            ],
            "Kenshi Yonezu":        [
                            ("Lemon", "Lemon", 2018),
                            ("Uchiage Hanabi", "Bootleg", 2017),
                            ("Shunrai", "Bootleg", 2017)
                            ]
            }
lt=[] #to temporarily store the list of tuples in the playlist
l=[] #gets the keys of the playlist
for i in playlist.keys():
    l.append(i)
l.sort()
l=l[-1::-1] #reverse alphabetical order
for i in l:
    lt=playlist[i]
    print(i,":")
    for j in lt:
        print(j[0],j[2],end="    ")
    print("\n")