print("Enter the size of the 2 lists") 
s1=int(input())
s2=int(input())
l1=[]
l2=[]
l3=[]
print("Enter the elements of l1")
for i in range(s1) : #obtaining elements of both the lists
    l1.append(int(input()))
print("Enter the elements of l2")
for i in range(s2) :
    l2.append(int(input()))
l3=l1 + l2 #adding all elements into another list l3 
max=l3[0]
min=max
for i in l3 : #basic check for min and max element
    if i>max :
        max=i
    if i<min :
        min=i
print(max,min)