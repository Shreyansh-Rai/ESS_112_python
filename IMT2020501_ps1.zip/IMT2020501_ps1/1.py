print("Enter the size of the list")
n=int(input())
l=[]

for i in range(n):
    l.append(int(input()))
m1=l[0]
m2=l[0]
for i in l:
    if i>m1 : #m1 is the largest element 
        m1=i
for i in l:
    if m1==m2: # to handle the case in which the first numer turns out to be the maximum number we simply change m2 
        m2=i #to any number that is not = m1 after this happens the second if will take care of everything
    if(i>m2 and i<m1) :#if i > m2 and if the i value is less m1 then update
        m2=i
print(m2)
#alternate approach using l.sort() 