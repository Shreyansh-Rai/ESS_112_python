p=float(input())
t=int(input())
r=float(input())
#assuming yearly compounding with rate r
ci=p*(1+r/100)**t
print(ci)