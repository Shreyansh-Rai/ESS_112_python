s=input()
s=list(s) #converting the string into a list 
spal=s[-1::-1] #storing the reverse into spal
s=str(s)
spal=str(spal) #both are converted into a string 
if spal == s : #check for palinidrome
    print("YES")
else :
    print("NO")
