import math
s=input()
l=s.split(',')
l1=[]
f=0
for i in range(len(l)):
    l[i]=int(l[i])
    if math.sqrt(l[i]) == math.floor(math.sqrt(l[i])) : #if the floor of the root = root then the number is a perf sq
        l1.append(int(math.sqrt(l[i]))) #adding the int of the square root to the list to be displayed
        f=1 #if the flag ramins 0 as initialised it means there are no perfect squares in the input numbers
if f==0:
    print("No Perfect Squares!")
else:
    print(l1)
    


