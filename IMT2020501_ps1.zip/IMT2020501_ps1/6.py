print("Enter the number of inputs")
n=int(input())
sq=0
for i in range(n) :
    sq+=int(input())**2 #calculating the sum of squares
print(sq/n)

