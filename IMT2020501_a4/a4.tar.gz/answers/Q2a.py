def print_n_messages():
	print("Hello world!\n"*10,end="") #print statement to print 10 times
print_n_messages()
