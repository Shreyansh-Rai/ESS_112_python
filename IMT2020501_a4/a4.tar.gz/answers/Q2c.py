def print_n_messages(m):
	for i in range(10):
		print(m)

if __name__=="__main__":
	print_n_messages(input()) 