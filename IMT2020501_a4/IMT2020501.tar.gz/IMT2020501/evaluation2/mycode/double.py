def double(l): return [2 * e for e in l]
