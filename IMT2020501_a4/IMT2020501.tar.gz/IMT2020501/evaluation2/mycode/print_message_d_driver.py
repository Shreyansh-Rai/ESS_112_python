import print_message_d

print_message_d.print_n_messages("Hi guys!", 15)
