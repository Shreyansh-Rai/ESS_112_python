def print_n_messages(n):
  for i in range(n):
    print("Hello world!")

if __name__ == "__main__":
  print_n_messages(10)
