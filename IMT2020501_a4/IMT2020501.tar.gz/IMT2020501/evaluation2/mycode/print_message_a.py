def print_n_messages():
  for i in range(10):
    print("Hello world!")

if __name__ == "__main__":
  print_n_messages()
