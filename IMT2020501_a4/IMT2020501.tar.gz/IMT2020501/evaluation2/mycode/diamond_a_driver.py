import diamond_a

diamond_a.diamond()
