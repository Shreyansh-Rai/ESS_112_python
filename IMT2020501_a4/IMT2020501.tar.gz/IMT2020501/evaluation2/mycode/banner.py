def banner(m):
    print("*" * (len(m) + 4))
    print("* " + m + " *")
    print("*" * (len(m) + 4))


