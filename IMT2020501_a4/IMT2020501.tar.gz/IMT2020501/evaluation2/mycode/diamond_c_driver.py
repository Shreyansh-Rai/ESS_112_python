import diamond_c

diamond_c.diamond(7, 'z')
