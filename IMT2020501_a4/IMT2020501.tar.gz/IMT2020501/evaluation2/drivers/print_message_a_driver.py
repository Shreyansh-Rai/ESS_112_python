import Q2a

Q2a.print_n_messages()
