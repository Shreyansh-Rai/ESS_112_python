import Q4b

Q4b.diamond(7)
