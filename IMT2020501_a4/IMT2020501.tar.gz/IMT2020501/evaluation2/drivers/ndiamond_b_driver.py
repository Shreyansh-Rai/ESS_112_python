import Q6

Q6.ndiamond(7)
