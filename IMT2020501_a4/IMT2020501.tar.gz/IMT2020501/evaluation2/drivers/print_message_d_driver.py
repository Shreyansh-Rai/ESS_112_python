import Q2d

Q2d.print_n_messages("Hi guys!", 15)
