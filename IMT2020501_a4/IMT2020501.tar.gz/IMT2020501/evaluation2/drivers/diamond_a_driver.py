import Q4a

Q4a.diamond()
