def print_n_messages(n):
	print("Hello world!\n"*n,end="")


if __name__=="__main__":
	n=int(input())
	print_n_messages(n) #function call for printing n times