def print_n_messages(m,n): #takes in m message and prints it n times
	for i in range(n):
		print(m)

if __name__=="__main__":
	print_n_messages(input(),int(input())) 