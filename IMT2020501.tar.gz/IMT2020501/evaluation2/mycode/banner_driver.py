import banner

banner.banner("Hi SKC!")
