def hello(n):  return "Hello " + str(n)
