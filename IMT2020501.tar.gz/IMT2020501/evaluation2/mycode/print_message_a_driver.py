import print_message_a

print_message_a.print_n_messages()
