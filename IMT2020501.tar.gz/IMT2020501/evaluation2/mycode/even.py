def even_elements(lst): return [n for n in lst if n % 2 == 0]
