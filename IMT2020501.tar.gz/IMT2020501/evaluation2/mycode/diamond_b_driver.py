import diamond_b

diamond_b.diamond(7)
