import print_message_b

print_message_b.print_n_messages(15)
