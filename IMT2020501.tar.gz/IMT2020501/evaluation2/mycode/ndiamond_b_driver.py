import ndiamond_b

ndiamond_b.ndiamond(7)
