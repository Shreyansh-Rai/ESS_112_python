import print_message_c

print_message_c.print_n_messages("Hi guys!")
