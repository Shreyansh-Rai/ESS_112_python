import ndiamond_a

ndiamond_a.ndiamond()
