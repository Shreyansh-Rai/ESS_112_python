def diamond():
  i =1
  while(i<6):
    spaces = abs(3-i)
    stars = 5 - 2*spaces
    print " "*spaces+"*"*stars
    i+=1


