def print_n_messages(n):
    i = 0
    while(i < n):
        print "Hello world!"
        i+=1

