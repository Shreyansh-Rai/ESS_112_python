def print_n_messages(m):
    i = 0
    while(i < 10):
        print m
        i+=1

