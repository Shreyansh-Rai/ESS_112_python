def print_n_messages(m,n):
    i = 0
    while(i < n):
        print m
        i+=1
