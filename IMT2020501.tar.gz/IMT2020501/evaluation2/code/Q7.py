def hello(name):
	return ("Hello "+name)

if __name__=="__main__":
	s=hello(input())
	print(s)