def double(l):
	return [2*i for i in l] #returning a list using liat comprehension.
	

if  __name__=="__main__":
	ltdg=[]
	ltgd= double([1,2,3]) #list that gets the value from double()
	print(ltgd)