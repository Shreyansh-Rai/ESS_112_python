import Q2c

Q2c.print_n_messages("Hi guys!")
