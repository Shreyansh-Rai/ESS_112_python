import Q4c

Q4c.diamond(7, 'z')
