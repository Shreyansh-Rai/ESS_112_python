import Q5

Q5.ndiamond()
