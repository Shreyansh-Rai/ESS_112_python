import Q2b

Q2b.print_n_messages(15)
