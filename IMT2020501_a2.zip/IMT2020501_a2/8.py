l=float(input())
b=float(input())
if l==b :
    print("Yes")
else :
    print("No")

