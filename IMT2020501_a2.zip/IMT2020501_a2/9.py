n=int(input())

if n>=80 and n<=100:
    print("A")
elif n>=60 and n<80: 
    print('B')
elif n>=50 and n<60:
    print('C')
elif n>=45 and n<50 :
    print("D")
elif n>=25 and n<45:
    print("E")
elif n<25 and n>=0:
    print("F")
else:
    print('Marks must lie in 0-100 range')
