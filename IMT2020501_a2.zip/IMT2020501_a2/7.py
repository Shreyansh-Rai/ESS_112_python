x=input()
print(len(x))
