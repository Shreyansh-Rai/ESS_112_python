a=int(input())
b=int(input())
c=int(input())
if a>b :
    if a>c:
        print("Largest Number:",a)
    else: 
        print("Largest Number:",c)
elif b>c :
    print("Largest Number:",b)
else :
    print("Largest Number:",c)

