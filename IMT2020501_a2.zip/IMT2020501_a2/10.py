ct= int(input())
ca= int(input())
pa= ca/ct *100
if pa >= 75 :
    print("Allowed")
else :
    print("Not Allowed")
    
