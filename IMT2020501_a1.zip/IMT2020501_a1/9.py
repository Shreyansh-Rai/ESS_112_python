import math
n= float(input("n = "))
if math.floor(n)== n : #if there is no decimal point in the number 
    print(int(n))
    print(int(n+1))
else : #if the numebr has a decimal point
    print(math.floor(n))
    print(math.ceil(n))
