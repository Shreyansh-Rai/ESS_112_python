a=int(input("a = "))
b=int(input("b = "))

#swapping without a temporary variable
a=a+b 
b=a-b # now b has a+b-b = a
a=a-b # now a has a+b -a =b
print('a =',a,'\nb =',b)