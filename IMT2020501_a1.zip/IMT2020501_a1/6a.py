a=int(input("a = "))
b=int(input("b = "))

#swapping with a temporary variable
temp=a
a=b
b=temp
print('a =',a,'\nb =',b)
