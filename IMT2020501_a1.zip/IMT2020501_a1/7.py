n= int(input()) # number to be evaluated in the given expression n^3+n^2+n

print(pow(n,3)+ pow(n,2) + n) 