dk= float(input()) # input for the distance in kilometers 
print ("km", end=' ')
dm= dk*0.621371 #conversion from k to miles
dm= round(dm,3)
print(dm, "miles")