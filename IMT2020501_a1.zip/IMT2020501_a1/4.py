x= int(input()) # x is the side of the square 

print("Diagonal length = ", round((pow(2,0.5)*x),2)) #root2*x for calculating the length of the diagonal
print("Perimeter = ", 4*x)
print("Area = ",x**2) #squaring x for finding the area of the square.

