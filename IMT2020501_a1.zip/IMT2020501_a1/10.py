x= float(input('x = '))
y=int(input('y = '))
print(f'The result of {x} to the power {y} is {round((pow(x,y)),2)}') #calculates and prints out the x^y operation
