a=int(input())
b=int(input())
print(a%b) # alternate logic could be that remainder= a - (a//b)*b
#print(a-a//b*b) alternate approach to printing remainder